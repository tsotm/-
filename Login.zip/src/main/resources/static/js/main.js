	// js正则验证相关字符的意义
	// 1.  /^$/ 这个是个通用的格式。
	// ^ 匹配输入字符串的开始位置；$匹配输入字符串的结束位置
    // 2. 里面输入需要实现的功能。
    // * 匹配前面的子表达式零次或多次；
    // + 匹配前面的子表达式一次或多次；
    // ？匹配前面的子表达式零次或一次；
    // \d  匹配一个数字字符，等价于[0-9]
    window.onload = function() {
        var isPage1 = document.getElementById("form") !== null;
        var isPage2 = document.getElementById("form2") !== null;

        if (isPage1) {
            // 在页面1中的处理逻辑
            document.getElementById("form").onsubmit = function() {
                return mailbox() && checkPassword() && checkPassword2() && imgCode();
            };
            document.getElementById("password").onblur = checkPassword;
            document.getElementById("password2").onblur = checkPassword2;
            document.getElementById("email").onblur = mailbox();
            // document.getElementById("checkcode").onblur = imgCode();
        }

        if (isPage2) {
            // 在页面2中的处理逻辑
            document.getElementById("form2").onsubmit = function() {
                return checkPassword() && checkPassword2() && checkPassword3() && imgCode();
            };
            document.getElementById("password").onblur = checkPassword;
            document.getElementById("password2").onblur = checkPassword2;
            document.getElementById("password3").onblur = checkPassword3;
        }
    };
    // window.onload = function(){
    //     document.getElementById("form2").onsubmit = function(){
    //         return checkPassword() && checkPassword2() && checkPassword3() && imgCode();
    //     };
    //     document.getElementById("password").onblur = checkPassword;
    //     document.getElementById("password2").onblur = checkPassword2;
    //     document.getElementById("password3").onblur = checkPassword3;
    //
    //     // document.getElementById("checkcode").onblur = imgCode;
    // }
    function checkPassword(){
            //固定六位到十位字符密码包含大小写字母与数字的组合，当然你也可以改变正则方式，详情可见https://www.jb51.net/article/115170.htm
            var password = document.getElementById("password").value;
            var reg_password = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,20}$/;
            var flag1 = reg_password.test(password);
            var s_password = document.getElementById("s_password");
            if(flag1){
                s_password.innerHTML = "<img width='35' height='25' src='img/right.png'/>";
                return true;
            }else{
                s_password.innerHTML = "密码格式有误";
                return false;
            }
        }
        function checkPassword2(){
            //与上步的password正则验证一样，加了个密码一致的匹配
            var password2 = document.getElementById("password2").value;
            var reg_password2 = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,20}$/;
            var flag2 = reg_password2.test(password2);
            var s_password2 = document.getElementById("s_password2");
            if(flag2 && password2 == document.getElementById("password").value){
                s_password2.innerHTML = "<img width='35' height='25' src='img/right.png'/>";
                 return true;
            }else{
                s_password2.innerHTML = "前后密码不一致";
                return false;
            }
        }
    function checkPassword3(){
        //固定六位到十位字符密码包含大小写字母与数字的组合，当然你也可以改变正则方式，详情可见https://www.jb51.net/article/115170.htm
        var password3 = document.getElementById("password3").value;
        var reg_password3 = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,20}$/;
        var flag3 = reg_password3.test(password3);
        var s_password3 = document.getElementById("s_password3");
        if(flag3){
            s_password3.innerHTML = "<img width='35' height='25' src='img/right.png'/>";
            return true;
        }else{
            s_password3.innerHTML = "密码格式有误";
            return false;
        }
    }
        function mailbox(){
        //定义正则表达式的变量:邮箱正则邮箱地址 必须由 大小写字母 或 数字 或下划线开头，其后可以跟上任意的 \w字符 和 中划线 加号 英文句号 @ 跟上任意的 \w字符 和 中划线(-) 加号 英文句号(.)
        var email =document.getElementById("email").value; 
        var emailReg=/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
         var flag = emailReg.test(email);
         var test_email = document.getElementById("test_email");
        if(flag)
        {
             test_email.innerHTML = "<img width='35' height='25' src='img/right.png'/>";
              return true;
        }else{
             test_email.innerHTML = "邮箱格式有误";
              return false;
        }
     }   
         // function imgCode(){
         //    //为了偷懒，写了个固定的验证码，验证码可以是动态改变，也可以静态更换，静态的利用js，用一个数组将验证码图片存起来//当用户点击更换验证码图片时，触发onclick事件更新验证码，用户可输入不同的验证码进行登录，但这样账号的安全性极其//的低(毕竟是前端验证🤣🤣🤣)
         //    var get_img=document.getElementById("checkcode").value;
         //   if(get_img== "7427"){
         //     code_input.innerHTML = "<img width='35' height='25' src='img/right.png'/>";
         //     return true;
         //   }
         //   else {
         //    code_input.innerHTML = "验证码输入有误，请重新输入";
         //    return false;
         //   }
         // }

        function checkform(){
            //表单总确认
       if(mailbox()  && checkPassword () && checkPassword2() && imgCode()==true){
        window.alert("恭喜您！注册成功");
		window.location.href="../index.html"
       }else{
        window.alert("请您核对一下您的注册信息是否有误");
        return false;
       }
    }