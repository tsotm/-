var newcode
function createCode() {
    var chars = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z', 'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1', '2','3','4','5','6','7','8','9','0'];
    var codeContainer = document.getElementById("code");
    var codes="";
    codeContainer.innerHTML = ""; // 清空之前的验证码

    for(var i = 0; i < 4; i++) {
        var randPosition = Math.floor(Math.random() * (chars.length - 1));
        var randCode = chars[randPosition];
        codes=codes+randCode.toLowerCase();
        var span = document.createElement("span");
        span.innerHTML = randCode;
        span.className = "code-char";
        span.style.color = getRandomColor(); // 设置随机颜色
        span.style.transform = "rotate(" + getRandomAngle() + "deg)"; // 设置随机角度
        codeContainer.appendChild(span);

    }
     console.log(codes)
    newcode=codes

}

function sendcode() {
    return newcode
}

function getRandomColor() {
    var letters = "0123456789ABCDEF";
    var color = "#";
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

function getRandomAngle() {
    return Math.floor(Math.random() * 30) - 30;
}

