package com.example.login.Service.Email;

import org.springframework.stereotype.Service;

import javax.mail.MessagingException;

@Service
public class EmailService {
    private int code;

    public void setCode(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public int sendEmailAndGetCode(String from, String to, String subject, String text) {
        int code = 100000 + (int) (Math.random() * 899999);

        Email email = new Email(from, to, subject, text + code);

        try {
            System.out.println("邮件正在发送，请稍等");
            email.send();
        } catch (MessagingException e) {
            e.printStackTrace();
        }

        this.code = code;
        return code;
    }

    public static void main(String[] args) {
        EmailService emailService = new EmailService();
        int code = emailService.sendEmailAndGetCode("qilangua19620213@163.com", "a2289652754@hotmail.com", "验证码", "你的验证码是：");
        System.out.println("验证码是：" + code);
    }

    public void toEmail(String email) {
        int code = sendEmailAndGetCode("qilangua19620213@163.com", email, "验证码", "你的验证码是：");
        System.out.println("验证码是：" + code);
    }
    public boolean verifyCode(int inputCode) {
        return inputCode == code;
    }
}
