package com.example.login.Service;

import com.example.login.Service.Email.EmailService;
import com.example.login.pojo.User;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    private static Logger logger= LoggerFactory.getLogger(UserService.class);
    @Autowired
    MongoTemplate mongoTemplate;
    @Autowired
    EmailService emailService;
    //判断密码是否合法
    public void isValid(String password) throws Exception {
        if (password.length() < 6){
            throw new Exception("密码不可小于6位");
        }
        String regex = "^[0-9a-zA-Z\\p{Punct}]+$";
        boolean hasPassword = password.matches(regex);
        if (hasPassword == false){
            throw new Exception("密码仅由特殊符号、大小写字母、数字组成");
        }
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasUpperCase = password.matches(".*[A-Z].*");
        boolean hasLowerCase = password.matches(".*[a-z].*");
        if ((hasDigit && hasUpperCase && hasLowerCase) == false){
            throw  new Exception("密码至少包含一个大写字母一个小写字母和一个数字");
        }
    }
    //创建新用户
    public void addUser(User user,Integer s) throws Exception{
        user.setID(user.getID().toLowerCase());
        if (user.getID().equals("") != true){
            Query addquery = new Query(Criteria.where("ID").is(user.getID()));
            User existingUser = mongoTemplate.findOne(addquery, User.class, "User");
            // 判断账号是否已存在
            if (existingUser != null) {
                throw new Exception("该用户已存在");
            }
        } else {
            throw new Exception("用户ID不能为空");
        }
        //判断密码是否合法
        isValid(user.getPassword());
        //判断是否为管理员注册
        if (user.getRoot().equals("") !=true){
            if (user.getRoot().equals("abc123")){
                user.setRoot("admin");
            }else{
                throw new Exception("管理员验证码错误，请重新注册");
            }
        }else{
            user.setRoot("user");
        }
        if (!emailService.verifyCode(s)) {
            throw new Exception("邮箱验证码错误");
        }
        mongoTemplate.insert(user,"User");
    }
    //删除用户
    public void deleteUserById(String ID) throws Exception {
        ID = ID.toLowerCase();
        System.out.println(ID);
        Query query = new Query(Criteria.where("ID").is(ID));
        System.out.println(query);
        if (query ==null){
            throw new Exception("用户不存在");
        }
        System.out.println("fh");
        mongoTemplate.remove(query, User.class,"User");
    }
    //修改密码
    public void  updateUserPasswordById(String ID,String  oldpassword,String newpassword) throws Exception{
        ID = ID.toLowerCase();
        Query query = new Query(Criteria.where("ID").is(ID));
        User existingUser = mongoTemplate.findOne(query, User.class,"User");
        if (!existingUser.getPassword().equals(oldpassword)){
            throw new Exception("旧密码不正确");
        }
        if (oldpassword.equals(newpassword)){
            throw new Exception("新密码不能与旧密码相同");
        }
        isValid(newpassword);
        Update update = new Update();
        update.set("Password",newpassword);
        mongoTemplate.updateFirst(query,update,User.class,"User");
    }

    public void  resetUserPasswordById(String ID,String  password,Integer s) throws Exception{
        ID = ID.toLowerCase();
        Query query = new Query(Criteria.where("ID").is(ID));
        User existingUser = mongoTemplate.findOne(query, User.class,"User");
        if (existingUser == null){
            throw new Exception("该用户不存在");
        }
        if (!emailService.verifyCode(s)) {
            throw new Exception("邮箱验证码错误");
        }
        isValid(password);
        Update update = new Update();
        update.set("Password",password);
        mongoTemplate.updateFirst(query,update,User.class,"User");
    }
    //修改权限
    public void updateUserRootById(String ID,String Root) throws Exception{
        ID = ID.toLowerCase();
        Query query = new Query(Criteria.where("ID").is(ID));
        Update update = new Update();
        update.set("Root",Root);
        mongoTemplate.updateFirst(query,update,User.class);
    }
    //查询用户
    public User getUserById(String ID) throws Exception {
        ID = ID.toLowerCase();
        if (ID.equals("") == true){
            throw  new Exception("请输入用户ID");
        }
        Query query = new Query(Criteria.where("ID").is(ID));
        User user = mongoTemplate.findOne(query, User.class,"User");
        if (user == null || user.getID() == null){
            throw new Exception("用户不存在2626");
        }
        return  user;
    }

    public List<User> getAllUser()
    {
        List<User>list=mongoTemplate.findAll(User.class,"User");
        return  list;
    }
}
