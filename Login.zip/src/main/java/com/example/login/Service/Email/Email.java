package com.example.login.Service.Email;// 导入javax.mail包

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

// 创建一个邮件类
public class Email {

    // 定义发送者，接收者，主题和内容
    private String from;
    private String to;
    private String subject;
    private String text;

    // 定义SMTP服务器的地址和端口
    private String host = "smtp.gmail.com";
    private int port = 587;

    // 定义发送者的账号和密码
    private String username = "qilangua19620213@163.com";
    private String password = "AMNIMBEOCSVXRLXY";

    // 定义一个构造方法，传入发送者，接收者，主题和内容
    public Email(String from, String to, String subject, String text) {
        this.from = from;
        this.to = to;
        this.subject = subject;
        this.text = text;
    }

    // 定义一个发送邮件的方法
    public void send() throws MessagingException {

        // 获取系统属性
        Properties properties = System.getProperties();

        // 设置邮件服务器的地址和端口
        properties.setProperty("mail.smtp.host", "smtp.163.com");
        properties.setProperty("mail.smtp.port", "25");

        // 设置邮件服务器需要认证
        properties.setProperty("mail.smtp.auth", "true");

        // 设置邮件服务器不使用TLS协议
        properties.setProperty("mail.smtp.starttls.enable", "false");

        // 设置邮件服务器使用SSL连接
        properties.setProperty("mail.smtp.starttls.enable", "true");


        // 获取默认的Session对象，并传入用户名和密码
        Session session = Session.getDefaultInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        // 创建一个MimeMessage对象
        MimeMessage message = new MimeMessage(session);

        // 设置发送者，接收者，主题和内容
        message.setFrom(new InternetAddress(from));
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
        message.setSubject(subject);
        message.setText(text);

        // 发送邮件
        Transport.send(message);
        System.out.println("邮件已送达");
    }
}


