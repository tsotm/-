package com.example.login.Service;

import com.example.login.pojo.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

@Service
public class OtherService {
    private static Logger logger= LoggerFactory.getLogger(OtherService.class);

    @Autowired
    MongoTemplate mongoTemplate;

    //判断登录
    public static void iflogin(User user, String password) throws Exception {
        if (password.equals("") == true){
            throw new Exception("请输入密码");
        }
        if (user != null && user.getPassword() != null && user.getPassword().equals(password)) {
        } else {
            throw new Exception("密码不正确");
        }
    }

}
