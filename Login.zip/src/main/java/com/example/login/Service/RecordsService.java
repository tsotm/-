package com.example.login.Service;

import com.example.login.pojo.Records;
import com.example.login.pojo.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

@Service
public class RecordsService {
    private static Logger logger= LoggerFactory.getLogger(RecordsService.class);
    @Autowired
    MongoTemplate mongoTemplate;
    //添加操作记录
    public void addRecords(String MID, String UID,String Controls) throws Exception{
        Records records = new Records();
        records.setMID(MID);
        records.setUID(UID);
        records.setControls(Controls);
        TimeZone timeZone = TimeZone.getTimeZone("Asia/Shanghai");
        TimeZone.setDefault(timeZone);
        // 获取当前时间
        Date currentDate = new Date();
        // 创建日期格式化对象
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // 格式化日期并输出
        String formattedDate = sdf.format(currentDate);
        records.setDate(formattedDate);
        mongoTemplate.insert(records,"Records");
    }
    //删除操作记录
    public void deleteRecordsById(String MID) throws Exception {
        Query query = new Query(Criteria.where("MID").is(MID));
        if (query ==null){
            throw new Exception("记录不存在");
        }
        mongoTemplate.remove(query, Records.class,"Records");
    }
    //查询管理员最新操作记录
    public Records getRecordsById(String MID) throws Exception {
        MID = MID.toLowerCase();
        if (MID.isEmpty()) {
            throw new Exception("请输入管理员ID");
        }

        Query query = new Query(Criteria.where("MID").is(MID));
        query.with(Sort.by(Sort.Direction.DESC, "date")); // 按时间倒序排序
        query.limit(1); // 限制结果返回一条记录

        Records records = mongoTemplate.findOne(query, Records.class, "Records");
        if (records == null || records.getMID() == null) {
            throw new Exception("用户不存在2626");
        }

        return records;
    }

    public List<Records> getAllRecords()
    {
        List<Records>list=mongoTemplate.findAll(Records.class,"Records");
        return  list;
    }
}
