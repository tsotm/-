package com.example.login.Service.Email;

public class OtherClass {
    private EmailService emailService;

    public OtherClass(EmailService emailService) {
        this.emailService = emailService;
    }

    public int getCodeFromTestEmail() {
        int code = emailService.getCode(); //调用TestEmail类的getter方法
        System.out.println("验证码是：" + code); //打印验证码的值
        return code;
    }


}