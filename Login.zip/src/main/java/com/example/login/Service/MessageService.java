package com.example.login.Service;

import com.example.login.Service.Email.EmailService;
import com.example.login.pojo.Message;
import com.example.login.pojo.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MessageService {

    private static Logger logger= LoggerFactory.getLogger(MessageService.class);
    @Autowired
    MongoTemplate mongoTemplate;
    @Autowired
    UserService userService;

    //添加/修改信息
    public void addMessgae(String ID,String UName,String Sex,String Birthday,String Signature) throws Exception{
        Query query = new Query(Criteria.where("ID").is(ID));
        Message message = mongoTemplate.findOne(query, Message.class,"Message");
        if (message  == null || message .getID() == null){
            System.out.println("添加");
            Message newmessage = new Message();
            newmessage.setID(ID);
            newmessage.setUName(UName);
            newmessage.setSex(Sex);
            newmessage.setBirthday(Birthday);
            newmessage.setSignature(Signature);
            System.out.println(newmessage);
            mongoTemplate.insert(newmessage ,"Message");
        }else{
            Update update = new Update();
            // 直接比较属性值，而不是使用equals()方法
            update.set("ID",ID);
                update.set("UName", UName);
                update.set("Sex", Sex);
                update.set("Birthday", Birthday);
                update.set("Signature", Signature);
            mongoTemplate.updateFirst(query, update, Message.class,"Message");
        }
    }
    //删除用户
    public void deleteMessageById(String ID) throws Exception {
        ID = ID.toLowerCase();
        Query query = new Query(Criteria.where("ID").is(ID));
        if (query ==null){
            throw new Exception("用户不存在");
        }
        mongoTemplate.remove(query, Message.class,"Message");
    }

    //查询用户
    public Message getMessageById(String ID) throws Exception {
        ID = ID.toLowerCase();
        if (ID.equals("") == true){
            throw  new Exception("请输入用户ID");
        }
        Query query = new Query(Criteria.where("ID").is(ID));
        Message message = mongoTemplate.findOne(query, Message.class,"Message");
        if (message  == null || message .getID() == null){
            throw new Exception("用户不存在");
        }
        return  message ;
    }

    public List<Message> getAllMessage()
    {
        List<Message>list=mongoTemplate.findAll(Message.class,"Message");
        return  list;
    }
    public List<Message> getAllMessageForAdmin() {
        List<Message> list = mongoTemplate.findAll(Message.class, "Message");

        List<Message> filteredList = new ArrayList<>();

        for (Message message : list) {
            String userID = message.getID();
            try {
                User user = userService.getUserById(userID);
                if (user.getRoot().equals("admin")) {
                    // 根据User的Root值为"admin"过滤结果
                    filteredList.add(message);
                }
                // 如果还需要根据其他Root值进行过滤，可以继续在此处添加相应的条件判断和处理
            } catch (Exception e) {
                logger.error("Failed to retrieve User with ID: " + userID, e);
            }
        }
        return filteredList;
    }
    public List<Message> getAllMessageForUser() {
        List<Message> list = mongoTemplate.findAll(Message.class, "Message");

        List<Message> filteredList = new ArrayList<>();

        for (Message message : list) {
            String userID = message.getID();
            try {
                User user = userService.getUserById(userID);
                if (user.getRoot().equals("user")) {
                    // 根据User的Root值为"admin"过滤结果
                    filteredList.add(message);
                }
                // 如果还需要根据其他Root值进行过滤，可以继续在此处添加相应的条件判断和处理
            } catch (Exception e) {
                logger.error("Failed to retrieve User with ID: " + userID, e);
            }
        }
        return filteredList;
    }
}
