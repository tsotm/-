package com.example.login.Controller;

import com.example.login.Service.MessageService;
import com.example.login.Service.UserService;
import com.example.login.pojo.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class MessageController {
    private static Logger logger= LoggerFactory.getLogger(MessageController.class);

    @Autowired
    MessageService messageService;
    @Autowired
    UserService userService;
    //修改用户信息
    @PostMapping("addMessage")
    public String addUser(String ID,String UName,String Sex,String Birthday,String Signature){

        try{
            messageService.addMessgae(ID,UName,Sex,Birthday,Signature);
            return "修改成功";
        }catch (Exception e) {
            return e.getMessage();
        }
    }

    //删除信息
    @GetMapping("delectMessage")
    public String delectMessage(String ID){
        try {
            messageService.deleteMessageById(ID);
            userService.deleteUserById(ID);
            return "删除成功";
        }catch (Exception e){
            return e.getMessage();
        }
    }

    //查询用户
    @GetMapping("getMessageByID")
    public Message getMessageById(String ID){
        try {
            Message message = messageService.getMessageById(ID);
            return message;
        } catch (Exception e) {
            logger.error("获取用户信息失败", e);
            return null;
        }
    }
    @GetMapping("getallMessage")
    public Map<String,Object> getAllMessage()
    {
        Map<String,Object>map=new HashMap<>();
        List<Message> list= messageService.getAllMessage();
        map.put("code","0");
        map.put("count",list.size());
        map.put("data",list);
        return  map;
    }

    @GetMapping("getallMessageForAdmin")
    public Map<String,Object> getAllMessageForAdmin()
    {
        Map<String,Object>map=new HashMap<>();
        List<Message> list= messageService.getAllMessageForAdmin();
        map.put("code","0");
        map.put("count",list.size());
        map.put("data",list);
        return  map;
    }

    @GetMapping("getallMessageForUser")
    public Map<String,Object> getAllMessageForUser()
    {
        Map<String,Object>map=new HashMap<>();
        List<Message> list= messageService.getAllMessageForUser();
        map.put("code","0");
        map.put("count",list.size());
        map.put("data",list);
        return  map;
    }
}
