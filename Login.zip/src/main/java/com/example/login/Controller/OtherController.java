package com.example.login.Controller;

import com.example.login.Service.Email.EmailService;
import com.example.login.Service.OtherService;
import com.example.login.Service.UserService;
import com.example.login.pojo.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@RestController
public class OtherController {
    private static Logger logger= LoggerFactory.getLogger(OtherController.class);

    @Autowired
    EmailService EmailService;
    @Autowired
    UserService UserService;
    @Autowired
    OtherService otherService;

    @GetMapping("toEmail")
    public String toEmail(String email){
        try{
            EmailService.toEmail(email);
            return "发送成功";
        }catch (Exception e) {
            return e.getMessage();
        }
    }
    @PostMapping("iflogin")
    public String iflogin(String ID, String Password){
        System.out.println(ID);
        System.out.println(Password);
        try{
            User use = UserService.getUserById(ID);
            OtherService.iflogin(use,Password);
            if (use.getRoot().equals("admin")){
                return "admin";
            }else {
                System.out.println("user");
                return "user";
            }
        }catch (Exception e){
            return e.getMessage();
        }
    };
}
