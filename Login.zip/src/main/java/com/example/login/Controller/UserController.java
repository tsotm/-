package com.example.login.Controller;

import com.example.login.Service.MessageService;
import com.example.login.Service.UserService;
import com.example.login.pojo.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class UserController {
    private static Logger logger= LoggerFactory.getLogger(UserController.class);

    @Autowired
    UserService userService;
    @Autowired
    MessageService messageService;
    //注册用户
    @PostMapping("addUser")
    public String addUser(User user,Integer s){
        System.out.println(user);
        try{
            userService.addUser(user,s);
            messageService.addMessgae(user.getID(),null,null,null,null);
            return "添加成功";
        }catch (Exception e) {
            return e.getMessage();
        }
    }
    //删除用户
    @GetMapping("delectUse")
    public String delectUse(String ID){
        try {
            userService.deleteUserById(ID);
            return "删除成功";
        }catch (Exception e){
            return e.getMessage();
        }
    }

    //修改密码
    @PostMapping("updateUserPasswordById")
    @ResponseBody
    public String updateUserPasswordById(String ID,String  oldpassword,String newpassword) {
        try {
            userService.updateUserPasswordById(ID,oldpassword,newpassword);
            return "成功";
        } catch (Exception e) {
            logger.error("修改密码失败", e);
            return "修改失败：" + e.getMessage();
        }
    }

    @PostMapping("resetUserPasswordById")
    public String  resetUserPasswordById(String ID,String Password,Integer s){
        System.out.println(ID);
        System.out.println(Password);
        try{
            userService.resetUserPasswordById(ID,Password,s);
            return "成功";
        } catch (Exception e) {
            logger.error("找回密码失败", e);
            return "找回失败：" + e.getMessage();
        }
    }
    //修改权限
    @PostMapping("updateUserRootById")
    @ResponseBody
    public String updateUserRootById(String ID,String Root) {
        try {
            userService.updateUserRootById(ID,Root);
            return "成功";
        } catch (Exception e) {
            logger.error("修改权限失败", e);
            return "修改失败：" + e.getMessage();
        }
    }

    //查询用户
    @GetMapping("getUserByID")
    public User getUserById(String ID){
        try {
            User user =  userService.getUserById(ID);
            return user;
        } catch (Exception e) {
            logger.error("获取用户信息失败", e);
            return null;
        }
    }

    @GetMapping("getallUser")
    public Map<String,Object> getAllUser()
    {
        Map<String,Object>map=new HashMap<>();
        List<User> list= userService.getAllUser();
        map.put("code","0");
        map.put("count",list.size());
        map.put("data",list);
        return  map;
    }
}
