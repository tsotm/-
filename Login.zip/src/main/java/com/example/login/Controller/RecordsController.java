package com.example.login.Controller;

import com.example.login.Service.MessageService;
import com.example.login.Service.RecordsService;
import com.example.login.pojo.Message;
import com.example.login.pojo.Records;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class RecordsController {
    private static Logger logger= LoggerFactory.getLogger(RecordsController.class);

    @Autowired
    RecordsService recordsService;

    //添加操作记录
    @PostMapping("addRecords")
    public String addRecords(String MID,String UID,String Controls){
        try{
            recordsService.addRecords(MID,UID,Controls);
            return "添加记录成功";
        }catch (Exception e) {
            return e.getMessage();
        }
    }

    //删除信息
    @GetMapping("delectRecords")
    public String delectRecords(String MID){
        try {
            recordsService.deleteRecordsById(MID);
            return "删除成功";
        }catch (Exception e){
            return e.getMessage();
        }
    }

    //查询用户
    @GetMapping("getRecordsByID")
    public Records getRecordsById(String MID){
        try {
            Records records = recordsService.getRecordsById(MID);
            return records;
        } catch (Exception e) {
            logger.error("获取操作记录失败", e);
            return null;
        }
    }

    @GetMapping("getallRecords")
    public Map<String,Object> getAllRecords()
    {
        Map<String,Object>map=new HashMap<>();
        List<Records> list= recordsService.getAllRecords();
        map.put("code","0");
        map.put("count",list.size());
        map.put("data",list);
        return  map;
    }
}
