package com.example.login.pojo;

import java.util.Date;

public class Message {
    private String ID;
    private String UName;
    private String Sex;
    private String Birthday;
    private String Signature;

    public Message(){};

    public Message(String ID, String UName, String Sex, String Birthday, String Signature) {
        this.ID = ID;
        this.UName = UName;
        this.Sex = Sex;
        this.Birthday = Birthday;
        this.Signature = Signature;
    }

    @Override
    public String toString() {
        return "Message{" +
                "ID=" + ID +
                ", UName='" + UName + '\'' +
                ", Sex='" + Sex + '\'' +
                ", Birthday=" + Birthday +
                ", Signature='" + Signature + '\'' +
                '}';
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getUName() {
        return UName;
    }

    public void setUName(String UName) {
        this.UName = UName;
    }

    public String getSex() {
        return Sex;
    }

    public void setSex(String Sex) {
        this.Sex = Sex;
    }

    public String getBirthday() {
        return Birthday;
    }

    public void setBirthday(String Birthday) {
        this.Birthday = Birthday;
    }

    public String getSignature() {
        return Signature;
    }

    public void setSignature(String Signature) {
        this.Signature = Signature;
    }
}
