package com.example.login.pojo;

import java.util.Date;

public class Records {
    private String MID;
    private String UID;
    private String date;
    private String Controls;

    public Records(){};

    public Records(String MID, String UID, String date,String Controls) {
        this.MID = MID;
        this.UID = UID;
        date = date;
        this.Controls = Controls;
    }

    @Override
    public String toString() {
        return "Records{" +
                "MID='" + MID + '\'' +
                ", UID='" + UID + '\'' +
                ", date='" + date + '\'' +
                ", Controls='" + Controls + '\'' +
                '}';
    }

    public String getMID() {
        return MID;
    }

    public void setMID(String MID) {
        this.MID = MID;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getControls() {
        return Controls;
    }

    public void setControls(String controls) {
        Controls = controls;
    }
}
