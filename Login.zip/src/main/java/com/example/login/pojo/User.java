package com.example.login.pojo;

public class User {
    private String ID;
    private String Password;
    private String Root;

    public User(){};

    public User(String ID, String Password, String Root) {
        this.ID = ID;
        this.Password = Password;
        this.Root = Root;
    }

    @Override
    public String toString() {
        return "User{" +
                "ID=" + ID +
                ", Password='" + Password + '\'' +
                ", Root='" + Root + '\'' +
                '}';
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getRoot() {
        return Root;
    }

    public void setRoot(String Root) {
        this.Root = Root;
    }
}
